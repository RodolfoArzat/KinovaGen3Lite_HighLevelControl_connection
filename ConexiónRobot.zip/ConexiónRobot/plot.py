import sys
import getopt
import matplotlib.pyplot as plt
import numpy as np

if __name__ == '__main__':
    data = np.genfromtxt(sys.argv[1],delimiter=',',names=True)
    t = data['time'] / 1000
    fig, axd = plt.subplot_mosaic([['q'],
                               ['qd',]], layout='constrained')
    Q = axd['q']
    QD = axd['qd']
    Q.set_title('e = qdes - q')
    QD.set_title('qd')
    for i in range(1, 8):
        Q.plot(t, data[f'q{i}'], label=f'$e_{i}$' )        
        QD.plot(t, data[f'qd{i}'] , label=f'$qd_{i}$' )
    Q.grid(True)
    Q.legend()
    QD.grid(True)
    QD.legend()
    plt.show()

 
